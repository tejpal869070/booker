export const CricketData = [
  {
    name: "Sri Lanka V/S India",
    type: "inplay",
  },
  {
    name: "Hampshire V/S Derbyshire",
    type: "inplay",
  },
  {
    name: "Surrey V/S Essex",
    type: "inplay",
  },
  {
    name: "Northamptonshire V/S Somerset",
    type: "tomorrow",
  },
];

export const FootballData = [
  {
    name: "Sri Lanka V/S Chaina",
    type: "inplay",
  },
  {
    name: "Nitherland V/S Africa",
    type: "today",
  },
  {
    name: "Surrey V/S Essex",
    type: "inplay",
  },
  {
    name: "Northamptonshire V/S Somerset",
    type: "tomorrow",
  },
];

export const TennisData = [
  {
    name: "India V/S Pak",
    type: "inplay",
  },
  {
    name: "USA V/S Canada",
    type: "tomorrow",
  },
  {
    name: "Surrey V/S Essex",
    type: "today",
  },
  {
    name: "Northamptonshire V/S Somerset",
    type: "tomorrow",
  },
];




export const mines = [
  { id: 1 },
  { id: 2 },
  { id: 3 },
  { id: 4 },
  { id: 5 },
  { id: 6 },
  { id: 7 },
  { id: 8 },
  { id: 9 },
  { id: 10 },
  { id: 11 },
  { id: 12 },
  { id: 13 },
  { id: 14 },
  { id: 15 },
  { id: 16 },
  { id: 17 },
  { id: 18 },
  { id: 19 },
  { id: 20 },
  { id: 21 },
  { id: 22 },
  { id: 23 },
  { id: 24 },
  { id: 25 },
];
