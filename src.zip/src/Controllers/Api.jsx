export const API = {
  url: "https://color.kmaobharat.com/",
  // url: "http://192.168.29.233:5999/",
  colorGameUrl: "https://color.kmaobharat.com/game/",
  gametype_hostURL: "https://color.kmaobharat.com/image/game-type/",
};

// export const API = {
//   url: "http://192.168.29.233:5999/",
//   colorGameUrl: "http://192.168.29.233:5999/game/",
//   gametype_hostURL: "http://192.168.29.233:5999/image/game-type/",
// };



// export const API = {
//   url: "https://api.stakebooker.com/",
//   // url: "http://192.168.29.233:5999/",
//   colorGameUrl: "https://api.stakebooker.com/game/",
//   gametype_hostURL: "https://api.stakebooker.com/image/game-type/",
// };


// export const API = {
//   url: "https://api.mt4life.in/",
//   // url: "http://192.168.29.233:5999/",
//   colorGameUrl: "https://api.mt4life.in/game/",
//   gametype_hostURL: "https://api.mt4life.in/image/game-type/",
// };