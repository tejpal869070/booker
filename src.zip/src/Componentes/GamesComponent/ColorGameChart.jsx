import React from 'react'

export default function ColorGameChart() {
  return (
    <div>ColorGameChart</div>
  )
}
